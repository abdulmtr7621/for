import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const roleEnum = z.enum(['helper', 'moderator', 'admin', 'developer', 'owner', 'user']);
export type Role = z.infer<typeof roleEnum>;

export const badgeEnum = z.enum(['new-member', 'member', 'climber', 'qubed', 'epic-qube', 'unique-qube', 'legendary-qube']);
export type Badge = z.infer<typeof badgeEnum>;

export const sectionEnum = z.enum([
  'general',
  'off-topic',
  'code-share',
  'support',
  'bot',
  'website',
  'player-reports',
  'bug-reports',
  'support-tickets',
  'dev-panel'
]);
export type Section = z.infer<typeof sectionEnum>;

export const users = pgTable("users", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  username: text("username").notNull().unique(),
  userId: text("user_id").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default('user'),
  badge: text("badge"),
  avatar: text("avatar"),
  banner: text("banner"),
  postCount: integer("post_count").default(0).notNull(),
  messageCount: integer("message_count").default(0).notNull(),
  warningPoints: integer("warning_points").default(0).notNull(),
  muted: boolean("muted").default(false).notNull(),
  mutedUntil: timestamp("muted_until"),
  banned: boolean("banned").default(false).notNull(),
  bannedUntil: timestamp("banned_until"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const posts = pgTable("posts", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  authorId: integer("author_id").notNull().references(() => users.id),
  section: text("section").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  deleted: boolean("deleted").default(false).notNull(),
  deletedBy: integer("deleted_by").references(() => users.id),
  status: text("status"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  recipientId: integer("recipient_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reactions = pgTable("reactions", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  postId: integer("post_id").notNull().references(() => posts.id),
  userId: integer("user_id").notNull().references(() => users.id),
  emoji: text("emoji").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const punishments = pgTable("punishments", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: integer("user_id").notNull().references(() => users.id),
  reason: text("reason").notNull(),
  warningPoints: integer("warning_points").notNull(),
  banDuration: integer("ban_duration"),
  issuedBy: integer("issued_by").notNull().references(() => users.id),
  appealed: boolean("appealed").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const appeals = pgTable("appeals", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: integer("user_id").notNull().references(() => users.id),
  punishmentId: integer("punishment_id").notNull().references(() => punishments.id),
  reason: text("reason").notNull(),
  approved: boolean("approved"),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const announcements = pgTable("announcements", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  authorId: integer("author_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  pinnedUntil: timestamp("pinned_until"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  userId: true,
  createdAt: true,
  badge: true,
  postCount: true,
  messageCount: true,
  warningPoints: true,
  muted: true,
  mutedUntil: true,
  banned: true,
  bannedUntil: true,
}).extend({
  username: z.string().min(3).max(20).regex(/^[a-z0-9_]+$/i, 'Username can only contain letters, numbers, and underscores'),
  password: z.string().min(6),
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deleted: true,
  deletedBy: true,
  status: true,
}).extend({
  authorId: z.number(),
  title: z.string().min(1).max(200),
  content: z.string().min(1).max(10000),
  section: sectionEnum,
});

export const updatePostSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  content: z.string().min(1).max(10000).optional(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
}).extend({
  senderId: z.number(),
  recipientId: z.number(),
  content: z.string().min(1).max(2000),
});

export const insertReactionSchema = z.object({
  postId: z.number(),
  emoji: z.string(),
});

export const insertPunishmentSchema = z.object({
  userId: z.number(),
  reason: z.string().min(1),
  warningPoints: z.number().min(1),
  banDuration: z.number().optional(),
});

export const insertAppealSchema = z.object({
  punishmentId: z.number(),
  reason: z.string().min(10),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type Reaction = typeof reactions.$inferSelect;
export type Punishment = typeof punishments.$inferSelect;
export type Appeal = typeof appeals.$inferSelect;
export type Announcement = typeof announcements.$inferSelect;

export const insertAnnouncementSchema = z.object({
  title: z.string().min(1).max(200),
  content: z.string().min(1).max(5000),
  pinnedUntil: z.date().optional(),
});

export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;

export type PostWithAuthor = Post & {
  author: User;
};

export type MessageWithUsers = Message & {
  sender: User;
  recipient: User;
};

export const BADGE_THRESHOLDS = {
  'new-member': 0,
  'member': 10,
  'climber': 35,
  'qubed': 80,
  'epic-qube': 150,
  'unique-qube': 225,
  'legendary-qube': 300,
};

export const COMMUNITY_RULES = [
  { category: 'Account/Real Money Trading', points: 4, duration: 5, description: 'Account/real money/third-party trading' },
  { category: 'Advertising', points: 7, duration: 6, description: 'Advertising products or services' },
  { category: 'Ban Evasion', points: 0, duration: 0, description: 'Ban (Permanent)', permanent: true },
  { category: 'Blackmailing', points: 4, duration: 5, description: 'Attempting to blackmail other users' },
  { category: 'Causing Drama', points: 1, duration: 2, description: 'Causing drama purposely' },
  { category: 'Cyber Threats', points: 4, duration: 5, description: 'Cyber/DDoS/death threats/wishes' },
  { category: 'Discrimination', points: 2, duration: 3, description: 'Discriminatory remarks' },
  { category: 'Doxxing', points: 0, duration: 0, description: 'Doxxing (threats) - Ban (Permanent)', permanent: true },
  { category: 'Encouraging Rule Breaking', points: 1, duration: 2, description: 'Encouraging breaking the rules' },
  { category: 'Falsifying Evidence', points: 0, duration: 0, description: 'Falsifying evidence - Ban (Permanent)', permanent: true },
  { category: 'Forbidden Files/Links', points: 4, duration: 5, description: 'Posting forbidden files/links' },
  { category: 'Going Off-Topic', points: 1, duration: 2, description: 'Going off-topic in sections' },
  { category: 'Inappropriate Usernames', points: 0, duration: 0, description: 'Inappropriate usernames - Ban (Permanent)', permanent: true },
  { category: 'Media Advertising', points: 2, duration: 3, description: 'Media advertising' },
  { category: 'Negative Behaviour', points: 1, duration: 2, description: 'Negative behaviour toward others' },
  { category: 'Negative Use of Disabilities', points: 3, duration: 4, description: 'Negative use of disabilities/diseases' },
  { category: 'Post Farming', points: 1, duration: 2, description: 'Post farming for engagement' },
  { category: 'Multiple Appeals', points: 2, duration: 3, description: 'Posting multiple appeals/applications' },
  { category: 'Reaction Spamming', points: 2, duration: 3, description: 'Reaction spamming' },
  { category: 'Removing Evidence', points: 4, duration: 5, description: 'Removing reported evidence' },
  { category: 'Seizure Content', points: 1, duration: 2, description: 'Seizure triggering content' },
  { category: 'Sexual Content', points: 1, duration: 2, description: 'Sexual/NSFW content' },
  { category: 'Spamming', points: 1, duration: 2, description: 'Spamming/flooding chat' },
  { category: 'Staff Impersonation', points: 2, duration: 3, description: 'Staff impersonating' },
  { category: 'Swearing', points: 1, duration: 2, description: 'Excessive swearing' },
];
